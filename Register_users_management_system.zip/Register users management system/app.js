const express = require("express");
const bodyParser = require("body-parser");

const app = express();

app.use(express.static("static"));
app.use(bodyParser.urlencoded({extended:true}));
app.set("view engine", "ejs");

let users = [];

function thisUserRegistered(email, password) {
  for (let i = 0; i < users.length; i++) {
    if (users[i].email === email && users[i].password === password) {
      return true;
    }
  }
  return false;
}

app.get("/", function(req,res){
  res.sendFile(__dirname + "/static/html/signup.html");
});

app.get("/users", function(req, res) {
  res.render("users", {users});
});

app.get("/edit", function(req, res) {
  const id = req.query.user;
  let user = users[id];
  if (!user) return res.redirect("/users");
  user['id'] = id;
  res.render("edit", {user});
});

app.post("/edit", function(req, res) {
  const id = req.body.id;
  const name = req.body.name;
  const email = req.body.email;
  const password = req.body.password;
  thisUserRegistered(email, password) ? res.redirect("/edit") : (users[id] = {name, email, password}, res.redirect("/users"));
});

app.post("/register", function(req, res) {
  const name = req.body.name;
  const email = req.body.email;
  const password = req.body.password;
  thisUserRegistered(email, password) ? res.redirect("/") : (users.push({name, email, password}), res.redirect("/users"));
});

app.post("/login", function(req, res) {
  const email = req.body.email;
  const password = req.body.password;
  thisUserRegistered(email, password) ? res.redirect("/users") : res.redirect("/");
});

app.listen(3000, function(){
  console.log("Server is running on port 3000");
});
